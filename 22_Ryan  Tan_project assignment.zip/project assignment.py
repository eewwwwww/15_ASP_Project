import numpy as np
import pandas as pd
import matplotlib.lines

data = open('dataNew.xls', "r",)
print(data.read())
# f = open("dataNew.xls", "r")
# print(f.read()